#ifndef IFECC_H_
#define IFECC_H_

#include <cstring>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <map>
#include <algorithm>
#include <queue>
#include <iostream>

#define POSINF 2147483647
#define NEGINF 0

using namespace std;

class Val
{
public:
    Val(int id, int val);
    int id, val;
    bool operator<(const Val &v) const;
};

class Vertex
{
public:
    vector<int> adj;
    int lb, ub, len;
};

class Graph
{
public:
    vector<Vertex> V;
    int n;
    vector<pair<int, int> > el;
    vector<int> landID;

public:
    Graph(string path);
    ~Graph();

public:
    int numLand;
    vector<int> landId;
    vector<vector<int> > disLand; //Distance from landmarks to V

    void create_landmark(int numLand);
    void select_landmark();
    void distance_landmark();
    void BFS(int uid, vector<int> &dis);

    inline void update_ub(int v, int ub);
    inline void update_lb(int v, int lb);

    vector<vector<Val> > listLand; //reverse list of each landmark
    void update_bound();

    vector<vector<int> > nodeGroup;
    void assign_group();

    void compute_ecc();
    void compute_ecc(int lid);
    int get_unmch(int lid);
};

//Implementation
bool Val::operator<(const Val &v) const
{
    return val == v.val ? id < v.id : val > v.val;
}

Val::Val(int id, int val)
{
    this->id = id;
    this->val = val;
}

Graph::Graph(string path)
{
    n = 0, numLand = 0;

    el.clear();
    FILE *in = fopen(path.c_str(), "r");
    for (int a, b; fscanf(in, "%d %d", &a, &b) != EOF;)
    {
        el.push_back(make_pair(a, b));
        n = max(max(n, a + 1), b + 1);
    }

    V.resize(n);
    for (int i = 0; i < el.size(); ++i)
    {
        if (el[i].first == el[i].second)
            continue;
        V[el[i].first].adj.push_back(el[i].second);
        V[el[i].second].adj.push_back(el[i].first);
    }

    long long m = 0;
    for (int i = 0; i < n; ++i)
    {
        sort(V[i].adj.begin(), V[i].adj.end());
        V[i].len = (int)V[i].adj.size();
        V[i].ub = POSINF;
        V[i].lb = NEGINF;
        m += V[i].len;
    }

    cout << "The number of vertices is " << n << " and the number of edges is " << m / 2 << endl;

    fclose(in);
}

Graph::~Graph()
{
}

void Graph::update_lb(int v, int lb)
{
    if (lb > V[v].lb)
        V[v].lb = lb;
}

void Graph::update_ub(int v, int ub)
{
    if (ub < V[v].ub)
        V[v].ub = ub;
}

void Graph::create_landmark(int numLand)
{
    this->numLand = numLand;
    select_landmark();
    distance_landmark();
    update_bound();
    assign_group();
}

void Graph::select_landmark()
{
    landId.clear();

    vector<Val> l;
    for (int i = 0; i < n; ++i)
        l.push_back(Val(i, V[i].len));
    sort(l.begin(), l.end());

    for (int i = 0; i < numLand; ++i)
        landId.push_back(l[i].id);
}

void Graph::distance_landmark()
{
    disLand.resize(numLand, vector<int>(n, 0));

    for (int i = 0; i < numLand; ++i)
    {
        int uid = landId[i];
        BFS(uid, disLand[i]);
    }
}

void Graph::BFS(int uid, vector<int> &dis)
{
    queue<int> toVisit;
    vector<int> visited;
    visited.resize(n, 0);

    toVisit.push(uid);
    visited[uid] = 1;
    dis[uid] = 0;

    while (!toVisit.empty())
    {
        int cur = toVisit.front();
        toVisit.pop();

        for (auto a : V[cur].adj)
        {
            if (visited[a] == 0)
            {
                visited[a] = 1;
                dis[a] = dis[cur] + 1;
                toVisit.push(a);
            }
        }
    }
}

void Graph::update_bound()
{
    listLand.resize(numLand);
    for (int i = 0; i < numLand; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            listLand[i].push_back(Val(j, disLand[i][j]));
            update_lb(j, disLand[i][j]);
        }
        sort(listLand[i].begin(), listLand[i].end());

        int ecc = listLand[i][0].val;
        for (int j = 0; j < n; ++j)
        {
            update_lb(j, ecc - disLand[i][j]);
            update_ub(j, ecc + disLand[i][j]);
        }
    }
}

void Graph::assign_group()
{
    nodeGroup.resize(numLand);
    for (int j = 0; j < n; ++j)
    {
        int gid = 0, dis = POSINF;
        for (int k = 0; k < numLand; ++k)
        {
            if (disLand[k][j] < dis)
            {
                gid = k, dis = disLand[k][j];
            }
        }
        nodeGroup[gid].push_back(j);
    }
}

void Graph::compute_ecc()
{
    for (int lid = 0; lid < numLand; ++lid)
    {
        compute_ecc(lid);
    }
}

int Graph::get_unmch(int lid)
{
    int unmch = 0;
    for (int i = 0; i < nodeGroup[lid].size(); ++i)
    {
        int id = nodeGroup[lid][i];
        if (V[id].ub != V[id].lb)
        {
            unmch++;
        }
    }
    return unmch;
}

void Graph::compute_ecc(int lid)
{
    int lambcnt = -1;
    int unmch = get_unmch(lid);

    while (unmch > 0)
    {
        lambcnt++;
        int uid = listLand[lid][lambcnt].id;
        vector<int> dis(n, 0);
        BFS(uid, dis);

        int ecc = NEGINF;
        for (int j = 0; j < n; ++j)
            ecc = max(ecc, dis[j]);
        V[uid].lb = V[uid].ub = ecc;
        int lambda = listLand[lid][lambcnt].val;

        for (int i = 0; i < nodeGroup[lid].size(); ++i)
        {
            int id = nodeGroup[lid][i];
            int lb = V[id].lb, ub = V[id].ub;
            if (lb < ub)
            {
                update_lb(id, dis[id]);
                if (dis[id] == ub)
                    continue;
                update_ub(id, max(V[id].lb, disLand[lid][id] + lambda));
            }
        }
        unmch = get_unmch(lid);
    }
}

#endif /* IFECC_H_ */