#include "dp.h"

string graph_name;

void test_graph() {

	long t = clock();
	printf( "loading graph ...\n" );
	string path = "raw/" + graph_name;


	string new_filepath = "data/";
	string new_path = new_filepath + graph_name;

	Graph g;
	g.input(path);
	g.conn();
	g.output(new_path);
}





int main(int argc, char *argv[]){
	graph_name = argv[1];


	printf("start\n");
    long t = clock();

    test_graph();

    t = clock() - t;
    printf("end\n");
    printf("total time=%0.3lf sec\n", t * 1.0 / CLOCKS_PER_SEC);
}
