#include "IFECC.h"

void test_graph(string path)
{
    path = "data/" + path;
    cout << path << endl;

    long tm = clock();
    printf("loading graph ...\n");
    Graph g(path);
    cout << "loading graph time = " << (clock() - tm) * 1.0 / CLOCKS_PER_SEC << " sec" << endl;

    tm = clock();
	
    g.create_landmark(10);
    g.compute_ecc();

    int r = 10000;
    int d = 0;
    for( int i = 0; i < g.n; ++i ){
        r = min(r,g.V[i].lb);
        d = max(d,g.V[i].lb);
    }
    cout << "r = " << r << ", d = " << d << endl;
    cout << "The time to calculate the ecc is " << (clock() - tm) * 1.0 / CLOCKS_PER_SEC << " sec" << endl;
}

int main(int argc, char *argv[])
{
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);

    string graph_name = argv[1];
    test_graph(graph_name);

    return 0;
}
