#include <cstring>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <map>
#include <algorithm>
#include <iostream>
#include <numeric>
#include <queue>
#include <cstdio>

#define MAXLINE 1024

typedef long long lint;


using namespace std;


class Val {
public:
	Val(int id, int val);
	int id, val;
	bool operator < (const Val& v) const;
};


class Graph {
public:
	vector<vector<int> > V;
	vector<int> deg;
	vector<int> old_new;
	int n;
	lint m;
	int id;

	vector< pair<int,int> > el;


public:
	Graph();
	~Graph();
	void input(string path);
	inline bool get_edge(char *line, int &a, int &b, int num_cnt = 2);
	inline int get_num_cnt(string path);

	void conn();
	void set_id();
	void output(string new_path);
};



bool Val::operator < (const Val& v) const {
	return val==v.val? id < v.id : val > v.val;
}

Val::Val(int id, int  val) {
	this->id = id;
	this->val = val;
}



Graph::Graph() {
 
}

Graph::~Graph() {
}

bool Graph::get_edge(char *line, int &a, int &b, int num_cnt) {
	if( !isdigit(line[0]) ) return false;
	vector<char*> v_num;
	int len = (int) strlen(line);
	for( int i = 0; i < len; ++i )
		if( !isdigit(line[i]) && line[i] != '.') line[i] = '\0';
		else if(i == 0 || !line[i-1]) v_num.push_back(line+i);
	if( (int) v_num.size() != num_cnt ) return false;
	sscanf( v_num[0], "%d", &a );
	sscanf( v_num[1], "%d", &b );
	return true;
}

int Graph::get_num_cnt(string path) {
	FILE *fin = fopen( path.c_str(), "r" );
	char line[MAXLINE], st[64];
	int cnt = 0, min_cnt = 100;

	while( fgets( line, MAXLINE, fin ) && cnt < 10 ) {
		if( !isdigit(line[0]) ) continue;
		vector<char*> v_num;
		int len = (int) strlen(line);
		for( int i = 0; i < len; ++i )
			if( !isdigit(line[i]) && line[i] != '.' ) line[i] = '\0';
			else if(i == 0 || !line[i-1]) v_num.push_back(line+i);
		if( (int) v_num.size() < 2 ) continue;
		min_cnt = min(min_cnt, (int) v_num.size());
		++cnt;
	}
	fclose( fin );
	return min_cnt;
}



void Graph::input(string path){
	FILE *fin = fopen( path.c_str(), "r" );
	char line[MAXLINE];
	int n = 0, a, b, num_cnt = get_num_cnt(path);
	lint cnt = 0, m = 0;
	el.clear();

	printf( "Loading text, num_cnt=%d...\n", num_cnt );
	while( fgets( line, MAXLINE, fin ) ) {
		if( !get_edge(line, a, b, num_cnt) ) continue;
		if( a < 0 || b < 0 || a == b ) continue;
		el.push_back(make_pair(a, b));
		n = max(max(n, a+1), b+1);
		if( (++cnt) % (lint) 10000000 == 0 ) printf( "%lld lines finished\n", cnt );
	}
	fclose( fin );

	V.clear();
	V.resize(n);
	deg.clear();
	deg.resize(n,0);
	printf( "Deduplicating...\n" );

	for(long long i = 0; i < el.size(); ++i) {
		V[el[i].first].push_back(el[i].second);
		V[el[i].second].push_back(el[i].first);
	}

	for( int i = 0; i < n; ++i ){
		if( V[i].size() > 0 ){
			sort( V[i].begin(), V[i].end() );
			int p = 1;
			for( int j = 1; j < (int) V[i].size(); ++j )
				if( V[i][j-1] != V[i][j] ) V[i][p++] = V[i][j];
			V[i].resize( p ); m += p;
			deg[i] = p;
		}
	}
	
	printf("n=%d,m=%lld\n",n,m);
	this->n = n;
}


void Graph::set_id(){
	vector<Val> t;
	t.clear();
	for(int i = 0; i < n; ++i){
		t.push_back(Val(i,deg[i]));
	}
	sort(t.begin(),t.end());
	id = t[0].id;

}



void Graph::conn(){
	id = 0;
	set_id();
	printf("id=%d\n",id);
	
	queue<int> to_visit;
	vector<int> vistied;
	vistied.resize(n);
	vector<int> dis;
	dis.clear();
	dis.resize(n);

	old_new.resize(n,-1);
	to_visit.push(id);
	vistied[id] = 1;

	int cnt = 0;
	dis[id] = 0;
	old_new[id] = cnt++;



	while (! to_visit.empty()) {
		int n_id = to_visit.front();
		to_visit.pop();

		for (vector<int>::iterator i = V[n_id].begin(); 
			 i != V[n_id].end(); 
			 i++) {
			if (vistied[*i] == 0) {
				vistied[*i] = 1;
				dis[*i] = dis[n_id] + 1;
				old_new[*i] = cnt++;
				to_visit.push(*i);
			}
		}
	}

	printf("# conn nodes=%d\n",cnt);
}


void Graph::output(string new_path){
	vector< pair<int,int> > n_el;
	n = 0;
	m = 0;

	for(int i = 0; i < el.size(); i++) {
		int a = el[i].first;
		int b = el[i].second;
		if(old_new[a] > -1 and old_new[b] > -1){
			int n_a = old_new[a];
			int n_b = old_new[b];
			n_el.push_back(make_pair(n_a, n_b));
			n = max(max(n,n_a+1),n_b+1);
		}
	}
	
	printf("n=%d\n",n);

	vector<vector<int> > V;
	V.clear();
	V.resize(n);
	printf( "Deduplicating...\n" );

	for(long long i = 0; i < n_el.size(); ++i) {
		V[n_el[i].first].push_back(n_el[i].second);
		V[n_el[i].second].push_back(n_el[i].first);
	}

	for( int i = 0; i < n; ++i ){
		if( V[i].size() > 0 ){
			sort( V[i].begin(), V[i].end() );
			int p = 1;
			for( int j = 1; j < (int) V[i].size(); ++j )
				if( V[i][j-1] != V[i][j] ) V[i][p++] = V[i][j];
			V[i].resize( p ); m += p;
		}
	}
	
	printf("n=%d,m=%lld\n",n,m/2);

	FILE *out = fopen(new_path.c_str(), "w");
    if (out == NULL) {
        fprintf(stderr, "can't write the graph file \n");
        exit(1);
    }

    lint cnt = 0;
    for(int i = 0; i < n; i++){
    	for(vector<int>::iterator it = V[i].begin(); it != V[i].end(); it++){
    		if(i < *it){
    			fprintf(out, "%d %d%c", i, *it, '\n');
    			if((++cnt) % (lint) 10000000 == 0 )
	    		printf( "%lld edges finished\n", cnt );
    		}
    	}
    }

    printf("n=%d,m=%lld\n",n,cnt);


    fclose(out);

	
	
}