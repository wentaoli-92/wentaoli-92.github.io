(1) download some graph to the file folder "raw"
Ex: raw/facebook.txt

(2) convert the graph to undirected and connected
1) g++ -O3 dp.cpp -o dp
2) ./dp graph_name
Ex: ./dp facebook.txt

(3) run the eccentricity processing algorithm
1) g++ -O3 -std=c++11 process.cpp -o process
2) ./process graph_name
Ex: ./process facebook.txt

