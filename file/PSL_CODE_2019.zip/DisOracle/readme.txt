This is the implementation of the paper "Scaling distance labeling on small-world networks". To exploit this code, please do the following instructions.

*0* Rename the file
For a dataset with the name "facebook.txt", create a file holder with the name "facebook" and place the txt file into the holder and change its name to "graph.txt".
=====================================

*1* Compile the source files
g++ -O3 -fopenmp DisOracle.cpp -o run
=====================================

*2* Obtain the binary representation of the dataset file
./run txt-to-bin @0 @1
@0: the name of the dataset
@1: whether the equivalent set elimination technique is used
Example:
(1) For PSL, run
./run txt-to-bin facebook/ 0
(2) For PLS+,run
./run txt-to-bin facebook/ 1
(3) For PLS*,run
./run txt-to-bin facebook/ 1
=====================================

*3* Create the index
./run index-dis @0 @1 @2 @3
@0: the name of the dataset
@1: the number of threads
@2: whether the local independent set elimination technique is used
@3: whether the index will be saved
Example:
(1) For PSL, run
./run index-dis facebook/ 1 0 1
(2) For PSL+, run
./run index-dis facebook/ 1 0 1
(3) For PSL*, run
./run index-dis facebook/ 1 1 1
=====================================

*4* Issue the distance queries
./run query-dis @0 @1
@0: the name of the dataset
@1: the number of distance queries
Example:
./run query-dis facebook/ 1000000










