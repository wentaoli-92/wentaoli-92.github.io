#include "dis.h"
#include "pll.h"


void index_pll(string path) {
	PrunedLandmarkLabeling<> pll;
	vector< pair<int,int> > el;

	FILE *fin = fopen( (path + "graph.txt").c_str(), "r" );
	char line[MAXLINE], st[64];
	int n = 0, a, b, num_cnt = DisOracle::get_num_cnt(path);
	lint cnt = 0, m = 0;

	printf( "Loading Data...\n" );
	while( fgets( line, MAXLINE, fin ) ) {
		if( !DisOracle::get_edge(line, a, b, num_cnt) ) continue;
		n = max(max(n, a+1), b+1);
		if( (++cnt) % (lint) 10000000 == 0 ) printf( "%lld lines finished\n", cnt );
		++m;
		el.push_back( make_pair(a,b) );
	}
	fclose( fin );
	printf( "n=%d,m=%lld\n", n, m );

	double t = omp_get_wtime();
	pll.ConstructIndex(el);
	pll.StoreIndex((path+"index-pll.bin").c_str());

	t = omp_get_wtime() - t;
	printf( "PLL: t=%0.3lf secs\n", t );
	pll.PrintStatistics();
}


void query_pll(string path, int n_pairs) {
	PrunedLandmarkLabeling<> pll;
	pll.LoadIndex((path+"index-pll.bin").c_str());
	int n = pll.GetNumVertices();
	printf( "query_pll: path=%s, num_v=%d, n_pairs=%d\n", path.c_str(), n, n_pairs );

	for( int r = 0; r < 5; ++r ) {
		long long td = 0, n_valid = 0;
		double t = omp_get_wtime();
		for( int i = 0; i < n_pairs; ++i ) {
			int u = rand() % n, v = rand() % n;
			int dis = pll.QueryDistance(u,v);
			if( dis < INT_MAX ) {td += dis; ++n_valid;}
		}
		t = omp_get_wtime() - t;
		printf( "round %d: average query time = %0.3lfns, average dis = %0.3lf\n", r+1, t*1000000.0/n_pairs, td*1.0/n_valid);
	}
}

void query_dis(string path, int n_pairs) {
	DisOracle d;
	d.load_idx(path);
	int n = d.n;
	printf( "query_dis: path=%s, num_v=%d, n_pairs=%d\n", path.c_str(), n, n_pairs );

	for( int r = 0; r < 5; ++r ) {
		long long td = 0, n_valid = 0;
		double t = omp_get_wtime();
		for( int i = 0; i < n_pairs; ++i ) {
			int u = rand() % n, v = rand() % n;
			int dis = d.query(u,v);
			if( dis < MAXD ) {td += dis; ++n_valid;}
		}
		t = omp_get_wtime() - t;
		printf( "round %d: average query time = %0.3lfns, average dis = %0.3lf\n", r+1, t*1000000.0/n_pairs, td*1.0/n_valid);
	}
}




int main(int argc, char *argv[]) {
	printf( "argc=%d\n", argc );
	for( int i = 0; i < argc; ++i )
		printf( "argv[%d]=%s\n", i, argv[i] );

	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	double t = omp_get_wtime();

	if( argc > 1 ) {
		if(strcmp( argv[1], "txt-to-bin" ) == 0)
			DisOracle::create_bin( /*dataset*/argv[2], /*merge*/argc>3?atoi(argv[3]):1, /*rank_method*/argc>4?atoi(argv[4]):0 );
		else if( strcmp(argv[1], "index-dis" ) == 0 )
			DisOracle::index_dis( /*dataset*/argv[2], /*threads*/argc>3?atoi(argv[3]):-1, /*indep*/argc>4?atoi(argv[4]):0, /*save*/argc>5?atoi(argv[5]):0 );
		else if( strcmp(argv[1], "index-pll" ) == 0 )
			index_pll( argv[2] );
		else if( strcmp(argv[1], "query-dis" ) == 0 )
			query_dis( argv[2], atoi(argv[3]) );
		else if( strcmp(argv[1], "query-pll" ) == 0 )
			query_pll( argv[2], atoi(argv[3]) );
	}


	t = omp_get_wtime() - t;
	printf( "total time=%0.3lf sec\n", t);

	return 0;
}
